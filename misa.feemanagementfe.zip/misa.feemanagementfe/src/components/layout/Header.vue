<template>
     <div class="header">
        <div class="nav-item-info">
            <div class="nav-item-name margin-left-16">Lập kế hoạch thu</div>
            <div class="help-icon"></div>
        </div>
        <div class="site-navigation">
            <div class="school">
                <div class="home"></div>
                <div>&lsqb;Thí điểm&rsqb; Trường mẫu giáo Edu Platform 1</div>
            </div>
            <div class="scholastic margin-left-16 margin-right-10">
                <select class="select">
                    <option>2018 - 2019</option>
                    <option>2019 - 2020</option>
                    <option>2020 - 2021</option>
                </select>
                
            </div> |
            <div class="search icon-24px"></div>
            <div class="avatar icon-24px margin-left-10"></div>
        </div>
    </div>
</template>