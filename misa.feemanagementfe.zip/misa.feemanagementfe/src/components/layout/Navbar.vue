<template>
    <div class="navbar">
      
            <div class="logo-box">
                <div class="revenue-icon"></div>
                <div class="revenue">Khoản thu</div>
                <div class = "option"></div>
            </div>

        <div class="navbar-content">
            <a class="nav-item">
                <div class="nav-item-icon nav-item-dashboard"></div>
                <div class="nav-item-text">Tổng quan</div>
            </a>
            <router-link class="nav-item" to="/dictionary/fee">
                <div class="nav-item-icon harvest-planning"></div>
                <div class="nav-item-text">Lập kế hoạch thu</div>
            </router-link>
            <a class="nav-item">
                <div class="nav-item-icon collection-manager"></div>
                <div class="nav-item-text">Quản lí thu</div>
            </a>
            <a class="nav-item">
                <div class="nav-item-icon bill-management"></div>
                <div class="nav-item-text">Quản lí hóa đơn</div>
            </a>
            <a class="nav-item">
                <div class="nav-item-icon receipts-and-payments"></div>
                <div class="nav-item-text">Số phải thu, phải trả</div>
            </a>
            
            <a class="nav-item">
                <div class="nav-item-icon report"></div>
                <div class="nav-item-text">Báo cáo</div>
            </a>
            <a class="nav-item">
                <div class="nav-item-icon message"></div>
                <div class="nav-item-text">Tin nhắn</div>
            </a>
            <router-link class="nav-item" to="/dictionary/system">
                <div class="nav-item-icon system"></div>
                <div class="nav-item-text">Hệ thống</div>
            </router-link>
        </div>
    </div>
</template>
<script>

export default {
  name: 'MenuBarLinks',
  data () {
    return {
      fee: '/dictionary/fee',
      system: '/dictionary/system'
    };
  }
};

</script>

