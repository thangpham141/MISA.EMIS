import Vue from 'vue'
import VueRouter from 'vue-router'
import Fee from '../views/dictionary/fee/FeeList.vue'
import System from '../views/dictionary/system/System.vue'
import FeeProfile from '../views/dictionary/fee/FeeProfileDetail.vue'
import Delte from '../views/dictionary/fee/DeleteForm.vue'
import Modify from '../views/dictionary/fee/DialogFeeModify.vue'

Vue.use(VueRouter)

const routes = [
  { path: '/', name: "Fee", component: Fee },
  // {
  //   path: '/about', name: 'About',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  // },
  {
    path: "/dictionary/fee",
    name: "Fee",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Fee
  },
  {
    path: "/dictionary/system",
    name: "System",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: System
  },
  {
    path: "/dictionary/fee-profile",
    name: "FeeProfile",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: FeeProfile
  },
  {
    path: "/dictionary/delete-form",
    name: "DeleteForm",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Delte
  },
  {
    path: "/dictionary/dialog-fee-modify",
    name: "DialogModify",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Modify
  },
 
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
