<template>
    <div class="content-body">
        <div class="header-content">
            <div class="title m-flex">
                <div class="title-name">Quy trình</div>
                <div class="title-name-select">Danh sách khoản thu</div>
                <div class="title-name">Đăng ký khoản thu</div>
                <div class="title-name">Danh sách miễn giảm</div>
                <div class="title-name-over" style="width:745px"></div>
            </div>
            <div class="content-feature m-flex">
                <div class="show-not-follow">
                    <input type="checkbox" name ="not-follow" value="không theo dõi"> Hiển thị khoản thu ngừng theo dõi
                </div>
                <div class="task-bar m-flex">
                    <div
                        class="margin-right-8 button-1"
                        v-on:click="btnAddOnClick"
                    >Thêm mới
                    </div>
                    <Details @closePopup="closePopup" :isHide="isHideParent" />
                    <div class="sort margin-right-8 button-2">Sắp lại thứ tự</div>
                    <div class="delete button-icon"></div>
                </div>
            </div>
        </div>
        <div class="body-content">
            <div class="fee-table margin-left-10 margin-right-10">
                <table id="contentTable">
                    <thead style="z-index: 1;">
                        <tr>
                            <th style="width:20px"><input type="checkbox"></th>
                            <th style="width:350px"
                            fieldName="FeeName"
                            >
                                <div>Tên khoản thu</div>
                                <div class="filter">
                                    <div class="icon-filter"></div>
                                    <div></div>
                                </div>
                            </th>
                            <th><div></div>Nhóm khoản thu
                            <div class="filter">
                                    <div class="icon-filter"></div>
                                    <div></div>
                                </div></th>
                            <th>
                                Mức thu
                                <div class="filter">
                                    <div class="icon-filter"></div>
                                    <div></div>
                                </div>
                            </th>
                            <th>
                                Kỳ thu
                                <div class="filter">
                                    <div class="icon-filter"></div>
                                    <div></div>
                                </div>
                            </th>
                            <th>
                                Thời điểm thu
                                <div class="filter">
                                    <div class="icon-filter"></div>
                                    <div></div>
                                </div>
                            </th>
                            <th>Áp dụng<br>miễn giảm</th>
                            <th>Cho xuất<br>hóa đơn</th>
                            <th>CHo xuất<br>chứng từ</th>
                            <th>Cho phép<br>hoàn trả</th>
                            <th>Khoản thu<br>bắt buộc</th>
                            <th>Đang<br>theo dõi</th>
                            <th></th>
                        </tr>
                        <!-- <tr>
                            <td><div style=""><input type="checkbox"></div></td>
                            <td>Đồng phục mùa đông</td>
                            <td>Đồng phục</td>
                            <td style="text-align: right;">400.000đ/năm</td>
                            <td>Năm</td>
                            <td>Hàng năm</td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td style="width:60px">
                                <div class="m-flex">
                                    <div class="icon-edit"></div>
                                    <div class="icon-duplicate"></div>
                                    <div class="icon-delete"></div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><div style=""><input type="checkbox"></div></td>
                            <td>Đồng phục mùa hè</td>
                            <td>Đồng phục</td>
                            <td style="text-align: right;">150.000đ/năm</td>
                            <td>Tháng</td>
                            <td>Hàng tháng</td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td style="width:60px">
                                <div class="m-flex">
                                    <div class="icon-edit"></div>
                                    <div class="icon-duplicate"></div>
                                    <div class="icon-delete"></div>
                                </div>
                            </td>
                        </tr> -->
                        <!-- <tr>
                            <td><div style=""><input type="checkbox"></div></td>
                            <td>Bàn ghế</td>
                            <td>Cơ sở vật chất</td>
                            <td style="text-align: right;">1.000.000đ/năm</td>
                            <td>Tháng</td>
                            <td>Hàng tháng</td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td style="width:60px">
                                <div class="m-flex">
                                    <div class="icon-edit"></div>
                                    <div class="icon-duplicate"></div>
                                    <div class="icon-delete"></div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><div style=""><input type="checkbox"></div></td>
                            <td>Học phí lớp 9</td>
                            <td>Học phí</td>
                            <td style="text-align: right;">40.000đ/Tháng</td>
                            <td>Tháng</td>
                            <td>Hàng tháng</td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td style="width:60px">
                                <div class="m-flex">
                                    <div class="icon-edit"></div>
                                    <div class="icon-duplicate"></div>
                                    <div class="icon-delete"></div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><div style=""><input type="checkbox"></div></td>
                            <td>Nước uống</td>
                            <td>Sinh hoạt</td>
                            <td style="text-align: right;">40.000đ/Tháng</td>
                            <td>Tháng</td>
                            <td>Hàng tháng</td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td><div class="icon-mark"></div></td>
                            <td style="width:60px">
                                <div class="m-flex">
                                    <div class="icon-edit"></div>
                                    <div class="icon-duplicate"></div>
                                    <div class="icon-delete"></div>
                                </div>
                            </td>
                        </tr> -->
                        <tr
                            class="el-table__row"
                            v-for="fee in fees"
                            :key="fee.feeId"
                            @dblclick="rowOnClick(fee)"
                        >
                            <td><div style=""><input type="checkbox"></div></td>
                            <td>
                            <div class="cell">{{ fee.feeName }}</div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.feeGroupID==1">Học phí</div>
                                <div v-show="fee.feeGroupID==2">Bán trú</div>
                                <div v-show="fee.feeGroupID==3">Quỹ</div>
                                <div v-show="fee.feeGroupID==4">Đồng phục</div>
                            </div>
                            </td>
                            <td>
                            <div class="cell" style="text-align: right;">{{ fee.price }}đ/{{fee.unit}}</div>
                            </td>
                            <td>
                            <div class="cell">{{ fee.property }}</div>
                            </td>
                            <td>
                            <div class="cell">{{ fee.period }}</div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.isApplyRemission" class="icon-mark"></div>
                            </div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.allowCreateInvoice" class="icon-mark"></div>
                            </div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.allowCreateReceipt" class="icon-mark"></div>
                            </div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.isSystem" class="icon-mark"></div>
                            </div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.isRequire" class="icon-mark"></div>
                            </div>
                            </td>
                            <td>
                            <div class="cell">
                                <div v-show="fee.isActive" class="icon-mark"></div>
                            </div>
                            </td>
                            <td style="width:60px">
                                <div class="m-flex">
                                    <div class="icon-edit"></div>
                                    <div class="icon-duplicate"></div>
                                    <div class="icon-delete"></div>
                                </div>
                            </td>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
        <div class="footer-content">
            <div>Tổng số: ... kết quả</div>
        </div>
    </div>
</template>
<script>
import * as axios from "axios";
import Details from "./FeeProfileDetail";
export default {
    name: "Fees",
  components: {
    Details,
  },
  methods: {
    btnAddOnClick() {
      this.isHideParent = false;
    },
    rowOnClick(fee){
      alert(fee.FeeName);
    },
    closePopup(value) {
      this.isHideParent = value;
    }
  },
  data() {
    return {
      isHideParent: true,
      fees:[],
    }
  },
  async created() {

    const response = await axios.get("http://localhost:56603/api/v1/fees");

    console.log(response.data[0]);

    this.fees = response.data;
  },
}
</script>
<style>
/*----------header-content------*/
    .header-content{
        height: 100px;
        margin: 0;
    }
    .header-content .title{
        align-content: center;
        height: 40px;
       
    }
    .header-content .content-feature{
        padding-top: 12px;
    }
    .header-content .content-feature .task-bar{
        position:absolute;
        right: 10px
    }
    .title-name{
        background-color: #eaecef;
        padding: 10px 20px 0px 20px;
        height: 100%;
        box-sizing: border-box;
        color: #cccccc;
        border-top: 2px solid #cccccc;
        cursor: pointer;
    }
    .title-name-over{
        background-color: #eaecef;
        padding: 10px 20px 0px 20px;
        height: 100%;
        box-sizing: border-box;
        color: #cccccc;
        border-top: 2px solid #cccccc;
    }
    .title-name:hover{
        border-top: 2px solid #03ae66;
        background-color: #e5f3ff;
        color: #03ae66;
    }
    .title-name:active{
        background-color: #ffffff;
    }
    .title-name-select{
        border-top: 2px solid #03ae66;
        background-color: #ffffff;
        color: #03ae66;
        padding: 10px 20px 0px 20px;
        height: 100%;
        box-sizing: border-box;
        cursor: pointer;
    }

/* ------body-content------ */
.body-content{
    height: calc(100vh - 200px);
    
}
/* #contentTable{
    height: calc(100vh - 205px);
    background: #e5f3ff;
    border: 1px solid black;
} */

/* ----footer-content---- */
.footer-content{
    position: absolute;
    bottom: 0;
    height: 50px;
    width: 100%;
    padding-left: 10px;
    box-sizing: border-box;
}
/* ---iconImg---- */
.delete{
    background-image: url("../../../assets/img&icon/ic_Delete_32.svg");
    width: 32px;
    height: 32px;
    background-size: cover;
}
.icon-delete{
    background: url('../../../assets/img&icon/ic_Remove2.svg') no-repeat;
	width: 20px;
	height: 20px;
    background-size: cover;
}
.icon-duplicate{
    background: url("../../../assets/img&icon/ic_Duplicate_24.svg") no-repeat;
	width: 20px;
	height: 20px;
    background-size: cover;
}
.icon-edit{
    background: url("../../../assets/img&icon/ic_Edit.svg") no-repeat;
	width: 20px;
	height: 20px;
    background-size: cover;
}
.icon-mark{
    background: url("../../../assets/img&icon/ic_Check.png");
	width: 20px;
	height: 20px;
    margin: auto;
}


</style>
