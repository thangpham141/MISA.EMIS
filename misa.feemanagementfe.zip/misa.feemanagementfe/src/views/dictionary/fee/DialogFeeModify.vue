<template>
  <div>
    <!-- <button id="btnAdd" class="m-btn m-btn-default" v-on:click="btnAddOnClick">
      <div class="m-btn-icon icon-add"></div>
      <div class="btn-text">Thêm nhân viên</div>
    </button> -->
    <div
      class="m-dialog dialog-detail"
      :class="{ isHide: isHide }"
    >
    <!-- nền đen -->
      <!-- <div class="dialog-modal"></div> -->
      <div class="dialog-content">
        <div class="dialog-header">
            <div class="title-profile">Sửa khoản thu</div>
            <div class="dialog-header-close">
            <div v-on:click="btnCancelOnClick" class="icon-close"></div>
            <!-- <button class="button-empty" v-on:click="btnCancelOnClick"><div class="icon-close"></div></button> -->

          </div>
        </div>
        <div class="dialog-body">
          <div class="profile-detail m-flex">
                <div class="detail-left m-flex-1">
                    <div class="m-col">
                        <div class="m-label">Tên khoản thu<span class="label-red"> *</span></div>
                        <div class="m-control">
                            <input class="input-text" type="text">
                        </div>
                    </div>
                    <div class="m-col-1">
                        <div class="m-label">Thuộc nhóm khoản thu</div>
                        <div class="m-control m-flex">
                            <div style="">
                                <select class="select-1">
                                    <option>Học phí</option>
                                    <option>Đồng phục</option>
                                    <option>Cơ sở vật chất</option>
                                </select>
                            </div>
                            <div class="icon-plus"></div>
                            <!-- <input class="input-text" type="text"> -->
                        </div>
                    </div>
                    <div class="m-col-1 m-flex">
                        <div class="" style="width: 250px">
                            <div class="m-label">Mức thu<span class="label-red"> *</span></div>
                            <div class="m-control">
                                <input class="input-text" type="text">
                            </div>
                        </div>
                        <div class="unit-d" style="margin: 29px 8px 0px 13px;">đ /</div>
                        <div class="" style="width: 83px">
                            <div class="unit">Đơn vị tính<span class="label-red"> *</span></div>
                            <div class="m-control">
                                <select>
                                    <option>Tháng</option>
                                    <option>Năm</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="m-col-1">
                        <div class="m-label">Phạm vi thu<span class="label-red"> *</span></div>
                        <div class="m-control">
                            <select>
                                    <option>Toàn trường</option>
                                    <option>Lớp</option>
                                    <option>Cá nhân</option>
                            </select>
                        </div>
                    </div>
                    <div class="m-col-1">
                        <div class="m-label">Tính chất</div>
                        <div class="m-control">
                            <select>
                                    <option></option>
                                    <option>Khoản thu bắt buộc</option>
                            </select>
                        </div>
                    </div>
                    <div class="m-col">
                        <div class="m-label">Kỳ thu<span class="label-red"> *</span></div>
                        <div class="m-control m-flex">
                            <div class="radio-profile">
                                <input type="radio" id="month" name="period" value="month">
                                <label for="month">Tháng</label>
                            </div>
                            <div class="radio-profile">
                                <input type="radio" id="quater" name="period" value="quater">
                                <label for="quater">Quý</label>
                            </div>
                            <div class="radio-profile">
                                <input type="radio" id="semester" name="period" value="semester">
                                <label for="semester">Học kỳ</label>
                            </div>
                            <div class="radio-profile">
                                <input type="radio" id="scholastic" name="period" value="scholastic">
                                <label for="scholastic">Năm học</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="detail-right m-flex-1">
                    <div class="m-col-2 m-flex">
                        <div class="m-flex m-flex-1">
                            <div class="checkbox-input margin-left-16"><input type="checkbox"></div>
                            <div>Áp dụng miễn giảm</div>
                        </div>
                        <div class="m-flex-1 m-flex">
                            <div class="checkbox-input"><input type="checkbox"></div>
                            <div>Cho phép xuất chứng từ</div>
                        </div>
                    </div>
                    <div class="m-col-2 m-flex">
                        <div class="m-flex m-flex-1">
                            <div class="checkbox-input margin-left-16"><input type="checkbox"></div>
                            <div>Khoản thu bắt buộc</div>
                        </div>
                        <div class="m-flex-1 m-flex">
                            <div class="checkbox-input"><input type="checkbox"></div>
                            <div>Cho phép hoàn trả</div>
                        </div>
                    </div>
                    <div class="m-col-2 m-flex">
                        <div class="m-flex m-flex-1">
                            <div class="checkbox-input margin-left-16"><input type="checkbox"></div>
                            <div>Cho phép xuất hóa đơn</div>
                        </div>
                        <div class="m-flex-1 m-flex">
                            <div class="checkbox-input"><input type="checkbox"></div>
                            <div>Thu nội bộ</div>
                        </div>
                    </div>
                    
                    <div class="m-col-2 m-flex">
                        <div class="margin-left-16 m-flex">
                            <div class="icon-switch-inactive"></div>
                            <div>Phân loại đăng ký</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="dialog-footer">
            <div class="btn-function m-flex">
                <div v-on:click="btnCancelOnClick" class="btn-close button-2">Đóng</div>
                <div @click="saveFee" class="btn-save button-1">Lưu</div>
            </div>
          <!-- <button id="btnCancel" class="m-btn m-btn-default m-btn-cancel" v-on:click="btnCancelOnClick">
            Hủy
          </button>
          <button id="btnSave" @click="saveEmployee" class="m-btn m-btn-default">
            <i class="far fa-save"></i><span class="btn-text">Lưu</span>
          </button> -->
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import * as axios from "axios";
export default {
  props: ['isHide'],
  methods: {
    btnAddOnClick() {
      // this.isHide = false;
    },
    btnCancelOnClick() {
      this.$emit('closePopup',true)
      // this.isHide = true;
    },
    rowOnClick(fee) {
      alert(fee.FullName);
    },
    async saveFee() {
      const response = await axios.post("http://api.manhnv.net/api/employees", this.employee);
        
      console.log(response);
    }
  },
  data() {
    return {
      dialog: false,
      display: "none",
    };
  },
};
</script>
<style scoped>
.isHide {
  display: none;
}
.m-dialog {
    position: relative;
    top: 60px;
  z-index: 999;
}

.dialog-header {
  position: relative;
  height: 40px;
  padding-left: 16px;
  display: flex;
}

.dialog-header-close {
  position: absolute;
  right: 16px;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  cursor: pointer;
  top: 10px;
  align-items: center;
  border: none;
  background-color: transparent;
  font-size: 24px;
  line-height: 24px;
}
.dialog-modal {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: black;
  opacity: 0.4;
}

.dialog-content {
    border: 1px solid black;
    position: fixed;
    border-radius: 5px;
    width: 880px;
    height: 550px;
    background-color: #fff;
    left: calc(50% - 400px);
    top: calc(50% - 300px);
}
.dialog-body {
  padding: 0 16px 16px 16px;
}
.dialog-footer {
  display: flex;
  width: 100%;
  border-radius: 0 0 5px 5px;
  align-items: center;
  justify-content: flex-end;
  padding: 12px 24px;
  box-sizing: border-box;
}

.title-profile{
        padding: 20px 0 0 20px;
    }
.profile-detail{
        margin: 16px 40px 16px 20px;
        height: 420px;
    }
.profile-detail .detail-left{
        padding-top: 10px;
        border-right: 1px solid #cccccc;
    }
.profile-detail .detail-right{
        padding-top: 10px;
    }
    .m-col{
        width: 365px;
        height: 60px;
    }
    .m-col-1{
        width: 370px;
        height: 60px;
    }
    .m-col-2{
        width: 365px;
        height: 40px;
    }
    .m-control{
        margin-top: 6px;
    }
    .radio-profile{
        margin-right: 30px;
        display: flex;
    }
    .icon-switch-inactive{
        margin-top: 3px;
        margin-right: 5px;
        width: 20px;
        height: 12px;
        background: url("../../../assets/img&icon/ic_Switch_Inactive.svg") no-repeat;
        background-size: cover;
    }
    .icon-close{
        /* position: relative;
        left: 684px;
        top: 10px; */
        width: 20px;
        height: 20px;
        background: url("../../../assets/img&icon/ic_close_16.png") no-repeat;
        background-size: cover;
    }
    .icon-plus{
        border: 1px solid #cccccc;
        border-left: none;
        border-radius: 0px 4px 4px 0px;
        width: 26px;
        height: 26px;
        background: url("../../../assets/img&icon/ic_Plus.svg") no-repeat;
        background-size: cover;
    }
    .checkbox-input{
        margin-top: 0px;
    }
 .btn-function{
        position: relative;
        left: 0px;
        top: -20px;
    }
    .btn-close{
        padding-left: 30px;
        padding-right: 30px;
        margin-right: 10px;
    }
    .btn-save-add{
        padding-left: 16px;
        padding-right: 16px;
        
    }
    .btn-save{
        padding-left: 30px;
        padding-right: 30px;
        margin-left: 10px;
    }
    select{
        height: 28px;
        border: 1px solid #cccccc;
        border-radius: 4px;
        width: 100%;
    }
    .select-1{
         border-radius: 4px 0px 0px 4px;
         width: 343px;
    }
    .m-label{
        color: #757575;
    }

</style>